package com.example.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.example.login.fragments.LoginFragment;
public class MainActivity extends AppCompatActivity implements LoginFragment.LoginListener {

    private FragmentManager fm = getSupportFragmentManager();
    //________________________ onCreate and other Activity functions ____________________________________

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fragment fragment  = new LoginFragment();
        fragment = fm.findFragmentById(R.id.fragment_container);


        if ((getIntent()!= null) && (getIntent().getData()!= null)) {
            FragmentTransaction fragmentTransaction = fm.beginTransaction();
        }

        else if (fragment == null) {
            fragment = new LoginFragment();
            // create a new instant this for login fragment
            ((LoginFragment) fragment).setLoginListener(this);
            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
        }
    }
    @Override
    protected  void onStart() {
        super.onStart();
        Log.d("TAG", "onStart() called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("TAG", "onResume() called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TAG", "onPause() called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("TAG", "onStop() called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("TAG", "onDestroy() called");
    }

    //--****************-- On Login success --***************--
    @Override
    public void loginComplete()
    {
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }


}